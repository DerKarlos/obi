import { Viewer } from './viewer.js';
import { ScenePos, default_height, rad, envRadius, limit, viewAngle } from "./utils.js"

// controldefaultmulti


/****   Simulate a control / expirience like F4-Map ****

The user of the PSM2World frondend lib instancietes a news osm2world-viewer and gets a viewer handler.
This handler accepts user defined controls. (This one may become the default control)
Actually, the handler has the atribute "scene" and this scene has all needed atributs anyway.
Is this a good way to handle "global variables" ???

The F4Input can be used for an ArcRotateCamera. A FreeCamera should work to, but dosn't yet.

With xrHelper, we once may have two cameras. This control then must handle both!

https://doc.babylonjs.com/divingDeeper/cameras/customizingCameraInputs

*/



export class ControlF4 { /////////////////////// Control (DEF OSM 2 WORLD) //////////////////////////////////

    private scene: BABYLON.Scene;

    /** The BabylonJS camera handler */
    public camera: BABYLON.ArcRotateCamera; //private???
    //    private viewAngle!: number;
    //    private viewAngleDef!: number;

    constructor(private viewer: Viewer) {

        this.scene = viewer.scene;

        this.camera = new BABYLON.ArcRotateCamera("Camera", 0, 0, 0, new ScenePos(0, 0, 0), this.scene);
        this.camera.setTarget(ScenePos.Zero());
        this.camera.minZ = 0.1;
        this.camera.maxZ = 100000;
        this.camera.lowerRadiusLimit = 0.5;
        this.camera.upperRadiusLimit = envRadius;
        this.camera.fov = rad(viewAngle); // Fly=40:F4=23  BJS:45.83662361046586
        //is.camera.radius = 200;
        //is.camera.target = new ScenePos(0, 0.5, -10);

        this.camera.upperBetaLimit = rad(90); // 90 = view horizontal: not under ground (API different!: 0=horizontal -90=down)
        this.camera.lowerBetaLimit = rad(0);  //  0 = view maximal down, no looping. But that's the limit anyway
        this.camera.panningSensibility = 3
        this.camera.inertia = 0.01; // default: 0.9
        this.camera.panningInertia = 0.01; // default: 0.9
        this.camera.target.y = default_height;
        //is.camera.useBouncingBehavior = true; // funny but not realy needed, may disturpe
        //is.camera.wheelDeltaPercentage = 0.005; // does NOT work well

        if (!this.viewer.canvas) { alert("!this.viewer.canvas"); return; }

        this.camera.attachControl(this.viewer.canvas, true);
        this.camera.inputs.attached.keyboard.detachControl(this.viewer.canvas); // Works, on-hooks are removed. But still attached :-/

// mousewheel, pointers

        this.camera.inputs.attached.mouse.detachControl(this.viewer.canvas);
        this.camera.inputs.add(new CameraKeyboardControl(this.scene, this));
        this.camera.inputs.add(new CameraMouseControl(this.scene, this));

        //        this.viewAngle = this.viewAngleDef = this.camera.fov; // to zoom in and out   ?use camera.fov???

        viewer.env.addCompass(this.camera);
    };




} //class ContolF4



/*
The BJS standard controls have arays of key codes for funtions. Like [Cursor-Up and Key-W].
But BJS don't use enums? I will! But I will not use arrays bud write it in the code explicit.
Is it realy neede to check if the key is used in the control? Yes if preventDefault shall work.
*/

class CameraMouseControl { /////////////////////////////////////// CameraMouseControl (BABYLON CONTROL) //////////////////////////////

    private canvas: HTMLCanvasElement | null;
    private engine: BABYLON.Engine;
    public camera = this.control.camera;

    private _onMouseDown: any; // ??? function(HTMLElement);
    private _onMouseMove: any;
    private _onMouseUp: any;
    private _onMouseWheel: any;
    private _onLostFocus: any;

    //  private point = {};
    private moved: boolean = false;
    private down: number = 0;  // mouse/touch: 0no/1st/2nd
    private max: number = Math.max(window.innerWidth, window.innerHeight)
    private lastX: number = -1;
    private lastY: number = -1;
    private startWidth: number = -1;
    private startHeight: number = -1;
    private actualWidth: number = -1;
    private actualHeight: number = -1;
    private movedWidth: number = -1;
    private movedHeight: number = -1;

    private startPosition = BABYLON.Vector3.Zero();
    private startRotation = BABYLON.Vector3.Zero();

    private minHeight: number = default_height;
    private maxHeight: number = envRadius * 0.65;  // below the limit vor the sky box

    constructor(scene: BABYLON.Scene, private control: ControlF4) {
        this.control = control;
        this.engine = scene.getEngine();
        this.canvas = this.engine.getRenderingCanvas();
        //  this.camera is set by BABYLON calling attachControl. It may also be the webVRCamera!



    }


    getClassName(): string {
        return "CameraMouseControl";
    };


    getTypeName(): string {
        return "OSM2WorldMouseInput";
    };


    getSimpleName(): string {
        return "OSM2WorldMous";
    };


    detachControl(element: HTMLElement): void {
        if (this._onMouseDown && this.canvas) {
            element.removeEventListener("onMouseDown", this._onMouseDown);
            element.removeEventListener("onMouseMove", this._onMouseMove);
            element.removeEventListener("onMouseUp", this._onMouseUp);
            element.removeEventListener("onMouseWheel", this._onMouseWheel);
            BABYLON.Tools.UnregisterTopRootEvents(window, [{
                name: "blur", //???
                handler: this._onLostFocus
            }]);
            //this.keysDown = [];
            this._onMouseDown = null;
            this._onMouseMove = null;
            this._onMouseUp = null;
            this._onMouseWheel = null;
        }
    };


    attachControl(element: HTMLElement, noPreventDefault?: boolean): void {

    //  let _this = this; //do???  is it the same as bind?
        if (!this._onMouseDown) {


            // KEY DOWN
            this._onMouseDown = function(evt: HTMLElement) {
                this.onPointDown(
                    evt.clientX,
                    evt.clientY, evt.button == 0 ? 1 : 2); // first/second button
                if (!noPreventDefault) {
                    evt.preventDefault();
                };

            };

            element.addEventListener("onMouseDown", this._onMouseDown);
            element.addEventListener("onMouseMove", this._onMouseMove);
            element.addEventListener("onMouseUp", this._onMouseUp);
            element.addEventListener("onMouseWheel", this._onMouseWheel);
            BABYLON.Tools.RegisterTopRootEvents(window, [{
                name: "blur", //???
                handler: this._onLostFocus
            }]);
        }

    }; //attachControl


    onMouseWheel(event: HTMLElement) {

    	event.preventDefault();
    	let wheel = 0;
    	if(event.wheelDelta !== undefined )  // WebKit / Opera / Explorer 9
    		 wheel =  event.wheelDelta
    	else
    	if (event.detail    !== undefined )  // Firefox
    		wheel = -event.detail

    	// Just one step, anyway how fast the wheel is spinning
    	let h = this.camera.position.y //height
    	var step = 0.05 *this.camera.radius; // distance camera to view-point
    	if(step<0.5) step = 0.5
    	if(wheel<0 && h<this.maxHeight) {
    		this.camera.radius += step;
    	//	this.passive = 0;
    	}

    	var min = 70; //(this.mode=="f4") ?	70 : 0.1
    	if(wheel>0 && h>this.minHeight && this.camera.position.z>min) {
    		this.camera.radius -= step;
    	//	this.passive = 0;
    	}

    	// At F4 each wheel+- is a zoom +- and shwon as Meter below 5,10,20,50,100,...20000km=Earth

    }


    onPointDown(px: number, py: number, down: number) {
        //let point = this.point;
        // Anfang der Bedienung merken (als +/-1 für Horizontal)
        this.actualWidth = this.startWidth = (px - window.innerWidth / 2) / window.innerWidth * 2
        this.actualHeight = this.startHeight = (py - window.innerHeight / 2) / window.innerWidth * 2
        this.movedWidth = this.movedHeight = 0
        this.moved = false;
        this.down = down

        this.startPosition = this.camera.target.clone();
        //  this.startPosition.y = cameraEle.position.y;
        this.startRotation = this.camera.rotation.clone();
        this.lastX = this.movedWidth
        this.lastY = this.movedHeight

        var show = "default";
        if (down == 1) show = "grabbing"; // grabbing,move
        if (down == 2) show = "crosshair"; // crosshair pointer all-scroll
        document.body.style.cursor = show;
    }

    onPointMove(px: number, py: number) {

        // Not dragging or not enabled.
        if (this.down == 0) return // Handle 2 buttons.

        //	this.passive = 0;
        // Calculate delta.
        this.actualWidth = (px - window.innerWidth / 2) / window.innerWidth * 2
        this.actualHeight = (py - window.innerHeight / 2) / window.innerWidth * 2
        this.movedWidth = this.actualWidth - this.startWidth
        this.movedHeight = this.actualHeight - this.startHeight
        if ((Math.abs(this.movedWidth) + Math.abs(this.movedHeight)) > (1 / this.max)) this.moved = true;
        //log(event.clientX, this.movedWidth)

        this.point_F4();

    }

    // runns cyclically while mouse is down and moves
    point_F4() {

        if (this.down == 1) {

            //r mouseAngleHeight = (event.clientY-window.innerHeight/2) / window.innerHeight * 65/180*Math.PI // 65 = grad Sicht-Breite
            var mouseAngleHeight = this.actualHeight * this.camera.fov / 2; // 65 = grad Sicht-Breite halbe ist maximal-Winkel
            var rx = -this.camera.rotation.x + mouseAngleHeight * 0.6		// x Summe der Rotationen
            //if(Math.abs(rx)<0.01) rx = -0.01 // Maximal 400? Meter
            var dz = this.camera.position.y / Math.tan(rx) * Math.cos(this.camera.rotation.x)  // z Abstand zur Kamerapositon
            var fhy = this.camera.position.y * window.innerWidth / this.camera.fov / 1300;  // y Faktor Horizontal?
            var fhz = dz * window.innerWidth / (this.camera.fov / 2) / 1600;  // SAUBER IST DAS HIER NOCH NICHT
            var deltaX = this.movedWidth * (fhy + fhz) / 14; // F4=14
            var deltaZ = this.movedHeight * (fhy + fhz) / 2; // F4=2?
            var positi = new BABYLON.Vector3(-deltaX, 0, -deltaZ)
/**
            var // Point-Verschiebung von controled-relaitv nach world umrechenn
                rotationEuler = new THREE.Euler(0, 0, 0, 'YXZ');
            rotationEuler.set(this.fly ? cameraArm.rotation.x : 0
                , cameraArm.rotation.y, 0);
            positi.applyEuler(rotationEuler);
**/
            // Addiern von Startposition und Verschiebung. Und setzen der Kamera
            this.camera.position.set(
                this.startPosition.x + positi.x,
                this.startPosition.y + positi.y,
                this.startPosition.z + positi.z)
        }


    }

}


class CameraKeyboardControl { /////////////////////////////////////// CameraKeyboardControl (BABYLON CONTROL) //////////////////////////////

    private canvas: HTMLCanvasElement | null;
    private engine: BABYLON.Engine;
    public camera = this.control.camera;

    private keysDown: any = {};

    private _onKeyDown: any; // ??? function(HTMLElement);
    private _onKeyUp: any;
    private _onLostFocus: any;

    //ivate fly:boolean	= false;
    //ivate lastHigh: boolean = false;
    private maxSpeed: number = 30;
    private accePosition: number = 100;
    private acceRotation: number = 30;
    private maxRotation: number = rad(15);

    private velocity = new BABYLON.Vector3(); // actual mass inertia relaitv ot object / LOCAL
    private spinning = new BABYLON.Vector3(); // also yerk (ruck) ?

    private minHeight: number = default_height;
    private maxHeight: number = envRadius * 0.65;  // below the limit vor the sky box

    constructor(scene: BABYLON.Scene, private control: ControlF4) {
        this.control = control;
        this.engine = scene.getEngine();
        this.canvas = this.engine.getRenderingCanvas();
        //  this.camera is set by BABYLON calling attachControl. It may also be the webVRCamera!

        let keyCodes: string[] = [
            'KeyA', 'ArrowLeft', // cursor keye
            'KeyD', 'ArrowRight',
            'KeyW', 'ArrowUp',
            'KeyS', 'ArrowDown',

            'KeyQ', 'KeyE', // rotate
            'KeyR', 'KeyF', // nick
            'KeyG', 'KeyT', // elevate

            'PageUp', 'PageDown',
            'Backslash', 'BracketRight', // ???

            'OSLeft', 'OSRight', // Option-Shiftkey
        ]
        keyCodes.forEach((code: string) => {
            this.keysDown[code] = false;
        });

        //    this.rotationRamp = new Ramp(this.sensibility, this.sensibility * 4); // slow down 4 times faster
        //    this.panningRamp = new Ramp(this.panningSensibility, this.panningSensibility * 4);
        //    this.joystick = new BABYLON.Vector2();


    } //constructor


    getClassName(): string {
        return "CameraKeyboardControl";
    };


    getTypeName(): string {
        return "OSM2WorldKeyboardInput";
    };


    getSimpleName(): string {
        return "OSM2WorldKey";
    };


    detachControl(element: HTMLElement): void {
        if (this._onKeyDown && this.canvas) {
            element.removeEventListener("keydown", this._onKeyDown);
            element.removeEventListener("keyup", this._onKeyUp);
            BABYLON.Tools.UnregisterTopRootEvents(window, [{
                name: "blur", //???
                handler: this._onLostFocus
            }]);
            this.keysDown = [];
            this._onKeyDown = null;
            this._onKeyUp = null;
        }
    };


    attachControl(element: HTMLElement, noPreventDefault?: boolean): void {

        let _this = this; //do???  is it the same as bind?
        if (!this._onKeyDown) {
            element.tabIndex = 1; // what's this?

            // KEY DOWN
            this._onKeyDown = function(evt: HTMLElement) {
                if (_this.keysDown[evt.code] != undefined) { // key is used by this control?
                    _this.keysDown[evt.code] = true;
                    if (!noPreventDefault) {
                        evt.preventDefault();
                    };
                };
            };

            // KEY UP
            this._onKeyUp = function(evt: HTMLElement) {
                if (_this.keysDown[evt.code] != undefined) {
                    _this.keysDown[evt.code] = false;
                    if (!noPreventDefault) {
                        evt.preventDefault();
                    };
                };
            };

            element.addEventListener("keydown", this._onKeyDown, false);
            element.addEventListener("keyup", this._onKeyUp, false);
            BABYLON.Tools.RegisterTopRootEvents(window, [{
                name: "blur", //???
                handler: this._onLostFocus
            }]);
        }
    }; //attachControl



    checkInputs(): void {

        let dSec = this.engine.getDeltaTime() / 1000;

        let camera = this.control.camera;
        let rotation = new BABYLON.Vector3(camera.beta, camera.alpha, 0);
        let position = camera.target.clone();
        //position.y = .position.y;

        let aPosition = new BABYLON.Vector3() // acceleration of porition and rotation, caused by user action
        let aRotation = new BABYLON.Vector3()

        //this.keys_F4plus(aPosition, aRotation);
        this.keys_F4(aPosition, aRotation);

        let factHeight = camera.position.y / 10;
        if (factHeight < 1.0)
            factHeight = 1.0

        // Accelerate velocity: velocity += acceleration * (acceleratoin * dSec time)
        this.velocity.addInPlace(aPosition.scale(this.accePosition * dSec * factHeight))
        let min3 = BABYLON.Vector3.One().scale(-this.maxSpeed * factHeight);
        let max3 = BABYLON.Vector3.One().scale(+this.maxSpeed * factHeight);
        this.velocity = BABYLON.Vector3.Clamp(this.velocity, min3, max3);

        this.spinning.addInPlace(aRotation.scale(this.acceRotation * dSec))
        min3 = BABYLON.Vector3.One().scale(-this.maxRotation);
        max3 = BABYLON.Vector3.One().scale(+this.maxRotation);
        this.spinning = BABYLON.Vector3.Clamp(this.spinning, min3, max3);

        // THREEJS: Controled relativ move to world move
        //        let rotationEuler = new THREE.Euler(0, 0, 0, 'YXZ');
        // let moving = this.velocity.clone().scale(dSec) // directionVector
        // Transform moving direction relative to heading.
        //        rotationEuler.set(this.fly ? rotation.x : 0
        //            , rotation.y
        //            , 0);
        // moving.applyEuler(rotationEuler);

        // BJS: Controled relativ move to world move
        let moving = new BABYLON.Vector3();
        // Quaternion works odd ???  this.velocity.scale(dSec).rotateByQuaternionToRef(rotation.toQuaternion(), moving);
        moving.x = - Math.sin(rotation.y) * this.velocity.x + Math.cos(rotation.y) * this.velocity.z
        moving.z = + Math.sin(rotation.y) * this.velocity.z + Math.cos(rotation.y) * this.velocity.x
        moving.y = this.velocity.y;

        // Increment position and rotation
        position.addInPlace(moving.scale(dSec))
        rotation.addInPlace(this.spinning)

        let h = camera.radius;
        let high = h > envRadius / 2; // 6000
        if (high) {
            rotation.x -= dSec;
            if (rotation.x < 0)
                rotation.x = 0;
        } else { // low
            let dif = rad(25) - rotation.x;
            if (dif > 0) {
                if (dif > dSec)
                    dif = dSec;
                rotation.x += dif;
            }
            if (rotation.x > rad(80))
                rotation.x = rad(80);
        }

        /** /

        this.actMaxAngle = ?;

        let min = rad(0);  // =down
        let max = rad(80); // =almost flat  start: 74
        let h = camera.position.y;
        let high = h > envRadius / 2; // 6000

        if (this.lastHigh != high) {
            this.lastHigh = high;
            if (high)
                rotation.y = 0; // =down
            else
                rotation.x = rad(25); // =much down     ???: 90-15=75/15=5*5=-25+90=65
        }

        if (high)
            max = rad(0); // =down    Zoom 15=2D 16=3D

        rotation.x = limit(min, rotation.x, max);
        /**/

        // If FPS too low, reset velocity and spin
        if (dSec > 0.9902) {	// MAX_DELTA
            this.velocity.set(0, 0, 0);
            this.spinning.set(0, 0, 0);
            aPosition.set(0, 0, 0);
            aRotation.set(0, 0, 0);
        }

        /***
        if(this.keys.KeyO || this.keys.Digit0){	// return to start/default position	 TODO: "Connection" ?
             this.keys.KeyO =  this.keys.Digit0 = false;
            position.copy(this.position0);
            rotation.copy(this.rotation0);
            this.spinning.set( 0, 0, 0 );
            this.velocity.set( 0, 0, 0 );
            camera.position.z = this.camPosit0;
            camera.fov = viewAngle = viewAngleDef; // zoom
            camera.updateProjectionMatrix();
        }
        ***/

        position.y = limit(this.minHeight, position.y, this.maxHeight);
        rotation.z = limit(-rad(90), rotation.z, +rad(90));
        rotation.x = limit(-rad(90), rotation.x, +rad(90)); // todo 45 ???
        rotation.y = rotation.y % (rad(360));

        camera.target.set(position.x, position.y, position.z);
        camera.alpha = rotation.y;
        camera.beta = rotation.x;
        //camera.rebuildAnglesAndRadius(); // NOT good

        this.velocity.set(0, 0, 0);
        this.spinning.set(0, 0, 0);

        // the more the camera is high abower ground, the more fast the camera moves

        let s = 300 / camera.position.y;  // in meter per mouse move // There is no PanningDeltaPercentage :( todo:BJS im forum meckern
        // if the camera is very close to the ground it would stop moving. avoid this
        if (s > 30)
            s = 30;
        camera.panningSensibility = s;

        camera.pinchPrecision = 50 / camera.position.y;

        // We use the original wheel control but munipulate it this way (in the key control!)
        // wheelDeltaPercentage does NOT work well :( todo:BJS im forum meckern
        camera.wheelPrecision = 100 / camera.radius;


    }; //checkInputs



    ///////////////////////////////////////////////////////////////////////////////////
    keys_F4(aPosition: BABYLON.Vector3, aRotation: BABYLON.Vector3) {

        let k = this.keysDown;

        var aZ = this.activity(k.ArrowUp || k.KeyW, k.ArrowDown || k.KeyS); // forward
        var sY = this.activity(k.ArrowLeft || k.KeyA, k.ArrowRight || k.KeyD); // arc horizontal

        // Additiv setting of 3DObject control
        aPosition.addInPlace(new BABYLON.Vector3(0, 0, +aZ));
        aRotation.addInPlace(new BABYLON.Vector3(0, -sY, 0));

    }//F4




    keys_F4plus(aPosition: BABYLON.Vector3, aRotation: BABYLON.Vector3) {

        // WASD, Pfeiltasten – Bewegung vor, zurück, links, rechts; jeweils parallel zur Ebene (Pan)
        // QERF - Rotation links/rechts/auf/ab um Kamerastandort (Rotate)
        // Bild hoch/runter T/G +/# - Höhe senkrecht zur Ebene verändern

        let k = this.keysDown


        // Accelerate
        let aX = this.activity(k.ArrowLeft || k.KeyA, k.ArrowRight || k.KeyD);
        let aZ = this.activity(k.ArrowUp || k.KeyW, k.ArrowDown || k.KeyS);
        let aY = this.activity(k.PageUp || k.KeyT || k.BracketRight, k.PageDown || k.KeyG || k.Backslash);
        if (aY > 0) aY /= 4

        // Spin
        let sY = this.activity(k.KeyQ, k.KeyE);
        let sX = this.activity(k.KeyR && !k.OSLeft && !k.OSRight, k.KeyF);

        // Additiv setting of 3DObject control
        aPosition.addInPlace(new BABYLON.Vector3(+aX, -aY / 30, +aZ)); // Z-asis is netativ into backround
        aRotation.addInPlace(new BABYLON.Vector3(-sX / 100, -sY / 100, 0)); //  ???/100 <=> acceRotation
    }




    /**
     * return an normed +/-1 value to de-/increse
     * @param sub  boolean  decrease
     * @param add  boolean  increase
     * @return     number   delta normed to 1
     */
    activity(sub: boolean, add: boolean) {
        let a = 0;
        if (sub) a -= 1;
        if (add) a += 1; // If both: 0
        return a;
    }


} //class CameraKeyboardControl
