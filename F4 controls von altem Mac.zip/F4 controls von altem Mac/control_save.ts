import { Viewer } from './viewer.js';
import { ScenePos, default_height, rad, degr, envRadius, limit } from "./utils.js"

// controldefaultmulti


/****   Simulate a control / expirience like F4-Map ****

The user of the PSM2World frondend lib instancietes a news osm2world-viewer and gets a viewer handler.
This handler accepts user defined controls. (This one may become the default control)
Actually, the handler has the atribute "scene" and this scene has all needed atributs anyway.
Is this a good way to handle "global variables" ???

The F4Input can be used for an ArcRotateCamera. A FreeCamera should work to, but dosn't yet.

With xrHelper, we once may have two cameras. This control then must handle both!

https://doc.babylonjs.com/divingDeeper/cameras/customizingCameraInputs

*/



export class Control { /////////////////////// Control (DEF OSM 2 WORLD) //////////////////////////////////

    private scene: BABYLON.Scene;

    /** The BabylonJS camera handler */
    public camera: BABYLON.ArcRotateCamera; //private???
    //    private viewAngle!: number;
    //    private viewAngleDef!: number;

    constructor(private viewer: Viewer, public mode?: string) {

        this.scene = viewer.scene;

        if(!this.mode) this.mode = "free";

        this.camera = new BABYLON.ArcRotateCamera("Camera", 0, 0, 0, new ScenePos(0, 0, 0), this.scene);
        this.camera.setTarget(ScenePos.Zero());
        this.camera.minZ = 0.1;
        this.camera.maxZ = 100000;
        this.camera.lowerRadiusLimit = 0.5;
        this.camera.upperRadiusLimit = envRadius;
        this.camera.fov = rad(23); // Fly=40:F4=23  BJS:45.83662361046586
        //is.camera.radius = 200;
        //is.camera.target = new ScenePos(0, 0.5, -10);

        this.camera.upperBetaLimit = rad(90); // 90 = view horizontal: not under ground (API different!: 0=horizontal -90=down)
        this.camera.lowerBetaLimit = rad(0);  //  0 = view maximal down, no looping. But that's the limit anyway
        this.camera.panningSensibility = 3
        this.camera.panningInertia = 0.01; // default: 0.9
        this.camera.target.y = default_height;
        //is.camera.useBouncingBehavior = true; // funny but not realy needed, may disturpe
        //is.camera.wheelDeltaPercentage = 0.005; // does NOT work well

        if (this.viewer.canvas)
            this.camera.attachControl(this.viewer.canvas, true);

        this.camera.inputs.attached.keyboard.detachControl(this.viewer.canvas); // Works, on-hooks are removed. But still attached :-/
        this.camera.inputs.add(new CameraInputControl(this.scene, this) as any); //any???

        //        this.viewAngle = this.viewAngleDef = this.camera.fov; // to zoom in and out   ?use camera.fov???

        viewer.env.addCompass(this.camera);
    };




} //class Contol



/*
The BJS standard controls have arays of key codes for funtions. Like [Cursor-Up and Key-W].
But BJS don't use enums? I will! But I will not use arrays bud write it in the code explicit.
Is it realy neede to check if the key is used in the control? Yes if preventDefault shall work.
*/

enum Key { // can't be inside the class :-(
    up = 38,
    down = 40,
    right = 39,
    left = 37,

    r = 82,
};



class CameraInputControl { /////////////////////////////////////// CameraInputControl (BABYLON CONTROL) //////////////////////////////

    private canvas: HTMLCanvasElement | null;
    private engine: BABYLON.Engine;

    private usedKeys: number[] = [
        Key.up, Key.down, Key.right, Key.left,
        Key.r,
    ]

    private keysDown: any[];

    private _onKeyDown: any;
    private _onKeyUp: any;
    private _onLostFocus: any;

    //    private fly:boolean	= false;
    private lastHigh: boolean = false;
    private easing: number = 200;
    private maxSpeed: number = 30;
    private accePosition: number = 30;
    private acceRotation: number = 10;
    private maxRotation: number = degr(15);

    private velocity = new BABYLON.Vector3(); // actual mass inertia
    private spinning = new BABYLON.Vector3(); // also yerk (ruck) ?

    private keys: any = {};

    constructor(scene: BABYLON.Scene, private control: Control) {
        this.control = control;
        this.engine = scene.getEngine();
        this.canvas = this.engine.getRenderingCanvas();
        //  this.camera is set by BABYLON calling attachControl. It may also be the webVRCamera!

        this.keysDown = [];

        //    this.rotationRamp = new Ramp(this.sensibility, this.sensibility * 4); // slow down 4 times faster
        //    this.panningRamp = new Ramp(this.panningSensibility, this.panningSensibility * 4);
        //    this.joystick = new BABYLON.Vector2();


    } //constructor


    getTypeName(): string {
        return "OSM2WorldKeyboardInput";
    };


    getSimpleName(): string {
        return "OSM2WorldKey";
    };


    detachControl(element: HTMLElement): void {
        if (this._onKeyDown && this.canvas) {
            element.removeEventListener("keydown", this._onKeyDown);
            element.removeEventListener("keyup", this._onKeyUp);
            BABYLON.Tools.UnregisterTopRootEvents(window, [{
                name: "blur",
                handler: this._onLostFocus
            }]);
            this.keysDown = [];
            this._onKeyDown = null;
            this._onKeyUp = null;
        }
    };


    attachControl(element: HTMLElement, noPreventDefault: boolean): void {

        let _this = this;
        if (!this._onKeyDown) {
            element.tabIndex = 1;
            this._onKeyDown = function(evt: HTMLElement) {
                if(this.usedKeys.indexOf(evt.keyCode) !== -1) {
                    let index = _this.keysDown.indexOf(evt.keyCode);
                    if (index === -1) {
                        _this.keysDown.push(evt.keyCode);
                    };
                    if (!noPreventDefault) {
                        evt.preventDefault();
                    };
                };
            };
            this._onKeyUp = function(evt: HTMLElement) {
                if(this.usedKeys.indexOf(evt.keyCode) !== -1) {
                    let index = _this.keysDown.indexOf(evt.keyCode);
                    if (index >= 0) {
                        _this.keysDown.splice(index, 1);
                    }
                    if (!noPreventDefault) {
                        evt.preventDefault();
                    };
                };
            };

            element.addEventListener("keydown", this._onKeyDown, false);
            element.addEventListener("keyup", this._onKeyUp, false);
            BABYLON.Tools.RegisterTopRootEvents(window, [{
                name: "blur",
                handler: this._onLostFocus
            }]);
        }
    }; //attachControl



    checkInputs(): void {

        let dSec = this.engine.getDeltaTime() / 1000;
        //        let rotateInput = 0;
        //        let panningInput = 0;
        //        let viewInput = 0;
        if (this._onKeyDown) {



            // Keyboard
            for (let index = 0; index < this.keysDown.length; index++) {
                let keyCode = this.keysDown[index];

                //                                this.keys['ArrowRight'] = (this.keysRight.indexOf(keyCode) !== -1);
                //                                this.keys['ArrowLeft'] = (this.keysLeft.indexOf(keyCode) !== -1);
                //                                this.keys['ArrowUp'] = (this.keysUp.indexOf(keyCode) !== -1);
                //                                this.keys['ArrowDown'] = (this.keysDown.indexOf(keyCode) !== -1);

                // switch case? Not possible
                //                if (this.keysLeft.indexOf(keyCode) !== -1) {
                //                    rotateInput += 1;
                //                } else if (this.keysRight.indexOf(keyCode) !== -1) {
                //                    rotateInput -= 1;
                //                } else if (this.keysUp.indexOf(keyCode) !== -1) {
                //                    panningInput += 1;
                //                } else if (this.keysDown.indexOf(keyCode) !== -1) {
                //                    panningInput -= 1;
                //                } else if (this.keysR.indexOf(keyCode) !== -1) {
                //                    viewInput += 1;
                //                }

            }
        } //keyDown

        this.tick(dSec);

    }; //checkInputs



    ///////////////////////////////////////////////////////////////////////////////////
    keys_default(
        aPosition: BABYLON.Vector3 //, aRotation: BABYLON.Vector3
    ) {

        // WASD, Pfeiltasten – Bewegung vor, zurück, links, rechts; jeweils parallel zur Ebene (Pan)
        // QERF - Rotation links/rechts/auf/ab um Kamerastandort (Rotate)
        // Bild hoch/runter T/G +/# - Höhe senkrecht zur Ebene verändern

        var k = this.keys

        // Accelerate
        var aX = this.activity(k.ArrowLeft || k.KeyA, k.ArrowRight || k.KeyD);
        var aZ = this.activity(k.ArrowUp || k.KeyW, k.ArrowDown || k.KeyS);
        var aY = this.activity(k.PageUp || k.KeyT || k.BracketRight, k.PageDown || k.KeyG || k.Backslash);
        if (aY > 0) aY /= 4

        // Spin
        //    	var sY = degr(this.activity( k.KeyQ,              k.KeyE));
        //    	var sX = degr(this.activity( k.KeyR && !k.OSLeft, k.KeyF));  // OSRight

        // Additiv setting of 3DObject control
        aPosition.add(new BABYLON.Vector3(+aX, -aY / 30, +aZ)) // Z-asis is netativ into backround
        //    	aRotation.add(new BABYLON.Vector3( -sX, -sY,      0))

    }



    tick(dSec: number) {
        let camera = this.control.camera;
        let rotation = new BABYLON.Vector3(camera.beta, camera.alpha, 0);
        let position = camera.target.clone();
        //position.y = .position.y;

        var aPosition = new BABYLON.Vector3() // acceleration of porition and rotation, caused by user action
        var aRotation = new BABYLON.Vector3()

        switch (this.control.mode) {
            case "free":
            case "point":
                this.keys_default(aPosition); // , aRotation
                break;
            //          case "f4":
            //              this.keys_F4(aPosition, aRotation);
            //              break;

        }

        var factHeight = camera.position.y / 10;
        if (factHeight < 1.0)
            factHeight = 1.0

        if (this.easing > 0) { // Ease by ramp
            this.rampDown3(this.velocity, aPosition, this.easing * factHeight, dSec)
            this.rampDown3(this.spinning, aRotation, this.easing, dSec)
        }

        // Accelerate velocity: velocity += acceleration * (acceleratoin * dSec time)
        this.velocity.add(aPosition.scale(this.accePosition * dSec * factHeight))
        let min3 = BABYLON.Vector3.One().scale(-this.maxSpeed * factHeight);
        let max3 = BABYLON.Vector3.One().scale(+this.maxSpeed * factHeight);
        this.velocity = BABYLON.Vector3.Clamp(this.velocity, min3, max3);
        this.spinning.add(aRotation.scale(this.acceRotation * dSec))
        min3 = BABYLON.Vector3.One().scale(-this.maxRotation);
        max3 = BABYLON.Vector3.One().scale(+this.maxRotation);
        this.spinning = BABYLON.Vector3.Clamp(this.spinning, min3, max3);

        //        var rotationEuler = new THREE.Euler(0, 0, 0, 'YXZ');
        var moving = this.velocity.clone().scale(dSec) // directionVector
        // Transform moving direction relative to heading.
        //        rotationEuler.set(this.fly ? rotation.x : 0
        //            , rotation.y
        //            , 0);

        // Controled relativ move to world move
        //        moving.applyEuler(rotationEuler);

        // Increment position and rotation
        position.add(moving)
        rotation.add(this.spinning)

        switch (this.control.mode) {

            case "free":
                rotation.x = limit(-degr(90), rotation.x, +degr(90));
                break;

            case "point":
                let h = camera.position.y;
                let max = -degr(limit(0, h / 30, 90));  // bei Höhe/5 in Meter zwangsweise den Blick -90° senkrecht nach unten
                let min = -degr(limit(0, h / 5, 90));  // bei Höhe   in Meter zwangsweise den Blick   0° wagerecht nach vorne
                rotation.x = limit(min, rotation.x, max);
                break;

            case "f4":
                h = camera.position.y;
                max = -degr(10); // F4:10
                min = -degr(90);

                var high = h > 6000;
                if (this.lastHigh != high) {
                    this.lastHigh = high;
                    if (high) rotation.y = 0;
                    else rotation.x = -degr(65); // 90-15=75/15=5*5=-25+90=65
                }

                if (high)
                    max = -degr(90);			// Zoom 15=2D 16=3D
                rotation.x = limit(min, rotation.x, max);
                break;
        }


    }



    /**
     * return an normed +/-1 value to de-/increse
     *
     * @param sub  boolean  decrease
     * @param add  boolean  increase
     * @return     number   delta normed to 1
     */
    activity(sub: number, add: number) {
        let a = 0;
        if (sub) a -= 1;
        if (add) a += 1; // If both: 0
        return a;
    }


    /**
     * low down of a value Vector3
     *
     * @param v3     Vector3  actual values
     * @param a3     Vector3  acceleration values
     * @param easing number   slowing down speed
     * @param dSec   number   delta time in seconds
     * @return       Vector3  new values after dSec
     */
    rampDown3(v3: BABYLON.Vector3, a3: BABYLON.Vector3, easing: number, dSec: number) {
        v3.x = this.rampDown(v3.x, a3.x, easing, dSec);
        v3.y = this.rampDown(v3.y, a3.y, easing, dSec);
        v3.z = this.rampDown(v3.z, a3.z, easing, dSec);
    }


    /**
     * low down of a value value
     *
     * @param v      number   actual value
     * @param a      number   acceleration value
     * @param easing number   slowing down speed
     * @param dSec   number   delta time in seconds
     * @return       number   new value after dSec
     */
    rampDown(v: number, a: number, easing: number, dSec: number) {
        if (a != 0) return v; // If accelerating: no easing

        let sign = Math.sign(v);
        v = Math.abs(v);
        if (v > easing) v -= easing;	// not near 0: substract
        else v = 0;	// else: set to 0
        return v * sign * dSec;
    }


} //class CameraInputControl
