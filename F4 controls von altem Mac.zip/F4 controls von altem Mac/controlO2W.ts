import { Viewer } from './viewer.js';
import { ScenePos, default_height, rad, limit, default_fov, phytagoras } from "./utils.js" // degr,

// controldefaultmulti



// going to contain all mode paramters

/**
 * Class/structur with parameters for the controler.
 * Set by the different modes of the controler.
 * @param minHeight Minimum Height of the camera-target abowe ground
 * @param maxHeight Maximum Height of the camera-target abowe ground
 */
class ControlParameter {

    constructor(public minHeight: number, public maxHeight: number) {
        ; // nop
    }

}



/** Simulate a user/camera control as expirience like F4-Map:
 * The user of the PSM2World frondend-lib instanciates a new osm2world-[[Viewer]] and gets a viewer handler.
 * This handler accepts user defined controls. (This one may become the default control)
 * Actually, the handler constructor has the atribute [[Viewer]] and this Viewer has all other needed atributs.
 *
 * The Control can be used for an ArcRotateCamera. A FreeCamera should work to, but dosn't yet.
 * This Control also works with a WebGL camera.
 *
 * https://doc.babylonjs.com/divingDeeper/cameras/customizingCameraInputs
 */
export class ControlO2W { /////////////////////// Control (DEF OSM 2 WORLD) //////////////////////////////////

    /** BJS scene */
    public scene: BABYLON.Scene;
    /** BJS engine */
    private engine: BABYLON.Engine;

    /** The BabylonJS camera handler */
    public camera!: BABYLON.ArcRotateCamera; //private???  // set in constructor_default

    /** Array of actual pressed keys */
    public keysDown: any = {};

    /** WebXR handler */
    public webXR: any;

    /** Pressed Oculus controler key A or B as a number +1/+/-1 */
    public keysAB: number = 0; // A B
    /** Pressed Oculus controler key Trigger or Squize as a number +1/+/-1 */
    public keysTS: number = 0; // trigger squize

    /** All needed parameter in a class/structure */
    public parameter!: ControlParameter; // set in constructor_default

    /** A BJS-ray checing in move direction */
    public ray = new BABYLON.Ray(new BABYLON.Vector3(0, 0, 1), new BABYLON.Vector3(0, -0.1, 30));
    /** BJS ray helper */
    public rayHelper = new BABYLON.RayHelper(this.ray);
    /** last ray move direction */
    public rayLastForward = 0;

    /**
     * ControlO2W constructor, called by the [[Viewere]].
     * @param viewer "parent" of the control
     * @param engine The usedBJS engine
     */
    constructor(public viewer: Viewer, public mode?: string) {
        this.scene = this.viewer.scene;
        this.engine = this.scene.getEngine();

        this.constructor_default();
        if (!mode) mode = "o2w";
        switch (mode) {
            case "f4": this.constructor_f4(); break;
            case "walk": this.constructor_walk(); break;
            default: this.constructor_o2w(); break;
        }

        this.rayHelper.attachToMesh(
            this.camera as unknown as BABYLON.AbstractMesh,
            new BABYLON.Vector3(0, 0, +1), // localMeshDirection
            new BABYLON.Vector3(0, -0.1, 0), //localMeshOrigin
            30 // length
        );
        // this.rayHelper.show(this.scene);

        // https://forum.babylonjs.com/t/even-by-using-evt-preventdefault-the-browser-menu-pops-up-after-i-changed-from-bjs-5-0-to-5-10/31383/7
        // HOTFIX NOT NEEDED ANY MORE: if (viewer.canvas) viewer.canvas.addEventListener("contextmenu",# (evt) => { evt.preventDefault(); });
    };


    /**
     * Called for all control-modes. Sets commen parameters and limits
     */
    constructor_default(): void {

        this.parameter = new ControlParameter(
            this.viewer.parameter.test >= 2 ?   // min
                0.05 : // 5cm
                default_height,                // max
            this.viewer.envRadius * 0.65        // below the limit vor the sky box
        );

        if (!this.scene.activeCamera)
            new BABYLON.ArcRotateCamera("Camera", 0, 0, 0, new ScenePos(0, 0, 0), this.scene);

        this.camera = this.scene.activeCamera as BABYLON.ArcRotateCamera;
        this.camera.setTarget(ScenePos.Zero());
        this.camera.minZ = 0.1;
        this.camera.maxZ = 100000;
        this.camera.lowerRadiusLimit = this.viewer.parameter.test >= 2 ? 0.10 : 65; //=F4
        this.camera.upperRadiusLimit = this.viewer.envRadius;
        this.camera.fov = rad(default_fov); // Fly=40:F4=23  BJS:45.8
        //mera.radius = 200;
        //mera.target = new ScenePos(0, 0.5, -10);

        this.camera.upperBetaLimit = rad(90); // 90 = view horizontal: not up (not 3rd person under ground) (API different!: 0=horizontal -90=down)
        this.camera.lowerBetaLimit = rad(0);  //  0 = view maximal down, no looping. But that's the limit anyway
        this.camera.panningSensibility = 3
        this.camera.inertia = 0; // 0.01; // default: 0.9
        this.camera.panningInertia = 0.01; // default: 0.9
        this.camera.target.y = default_height;
        //mera.useBouncingBehavior = true; // funny but not realy needed, may disturpe
        //mera.wheelDeltaPercentage = 0.005; // does NOT work well
        this.camera.wheelPrecision /= 10;   // not good either:  =100/camera.radius;

        //if (!this.viewer.canvas) { alert("Missing: this.viewer.canvas"); }
        this.camera.attachControl(this.viewer.canvas, false);  // ,noPreventDefault
        //mera.inputs.attached.mousewheel  default is used

        if (true) { // use the own key control
            this.camera.inputs.attached.keyboard.detachControl(); // Works, on-hooks are removed. But still attached :-/
            this.camera.inputs.add(new CameraKeyboardControlO2W(this.scene, this));
        }

        if (true) { // use the own pointer
            this.camera.inputs.attached.pointers.detachControl();
            this.camera.inputs.add(new CameraMouseControlO2W(this));
        }

        // this.camera.inputs.attached.mousewheel.detachControl(this.viewer.canvas);

        this.viewer.env.addCompass(this.camera);
    }


    /**
     * Called for the control-mode "o2w".
     * Sets a lower minimum distance to the view target
     */
    constructor_o2w(): void {
        this.camera.lowerRadiusLimit = 0.50;
    }


    /**
     * Called for the control-mode "f4".
     */
    constructor_f4(): void {
        // nothing to do yet
    }


    /**
     * Called for the control-mode "walk".
     * Sets the radius to amost zero. The ArcRotateCamera becomes a "free" camera.
     */
    constructor_walk(): void {
        this.camera.lowerRadiusLimit =
            this.camera.upperRadiusLimit = 0.01;
        this.camera.upperBetaLimit = rad(160); // 90 = view horizontal: not under ground (API different!: 0=horizontal -90=down)
        this.camera.lowerBetaLimit = rad(20);  //  0 = view maximal down, no looping. But that's the limit anyway

        this.parameter = new ControlParameter(
            default_height / 2,  // min: bent over
            default_height     // max: upright
        );

        // todo
    }


    /**
     * If the user sets the parameter, this is called and activates the WebXR/VR mode.
     * @param allButtons Enable the WebXR controler buttons
     * @param options Options handed over to the WebXR initialisation
     */
    async activateWebXrAsync(allButtons: boolean, options?: any) {
        //                            createDefaultXRExperienceAsync  // is replacec by:
        this.webXR = await this.scene.createDefaultImmersiveExperienceAsync(options)  // from: immersive.js
        this.webXR.teleportation.addFloorMesh(this.viewer.env.shadowGround);

        this.webXR.baseExperience.onStateChangedObservable.add((state: any) => {
            console.log("onStateChangedObservable:", state)
            switch (state) {
                case BABYLON.WebXRState.ENTERING_XR:
                    // xr is being initialized, enter XR request was made
                    if (this.viewer.osmScene) this.viewer.osmScene.startWebXR();
                    break;
                case BABYLON.WebXRState.IN_XR:
                    // XR is initialized and already submitted one frame
                    break;
                case BABYLON.WebXRState.EXITING_XR:
                    // xr exit request was made. not yet done.
                    break;
                case BABYLON.WebXRState.NOT_IN_XR:
                    // self explanatory - either out or not yet in XR
                    break;
            }
        })

        // https://doc.babylonjs.com/divingDeeper/webXR/webXRARFeatures

        if (allButtons && this.webXR && this.webXR.input && this.webXR.input.onControllerAddedObservable) {

            this.webXR.input.onControllerAddedObservable.add((xrController: any): void => { // WebXRInputSource instance
                xrController.onMotionControllerInitObservable.add((motionController: any): void => {
                    if (motionController.handness == "right") {

                        //// trigger //// no Axis (emulation "sqeeze button")
                        const main = motionController.getComponent("xr-standard-trigger");
                        main.onButtonStateChangedObservable.add((component: any): void => {
                            if (typeof (component.changes.value) !== "undefined")
                                this.keysTS = -component.changes.value.current;
                        })


                        //// squeeze //// no Axis
                        const squeeze = motionController.getComponent("xr-standard-squeeze");
                        squeeze.onButtonStateChangedObservable.add((component: any): void => {
                            if (typeof (component.changes.value) !== "undefined")
                                this.keysTS = +component.changes.value.current;
                        });




                        //// a-button //// no Axis
                        const buttonComponenta = motionController.getComponent("a-button");
                        buttonComponenta.onButtonStateChangedObservable.add((component: any): void => {
                            if (typeof (component.changes.value) !== "undefined")
                                this.keysAB = -component.changes.value.current;
                        });

                        //// b-button //// no Axis
                        const buttonComponentb = motionController.getComponent("b-button");
                        buttonComponentb.onButtonStateChangedObservable.add((component: any): void => {
                            if (typeof (component.changes.value) !== "undefined") {
                                this.keysAB = +component.changes.value.current;
                            }
                        });

                    }// right
                });//MotionControllerInit
            });//ControllerAdded



            this.scene.registerBeforeRender(() => {

                let dSec = this.engine.getDeltaTime() / 1000;
                let camera = this.scene.activeCamera as BABYLON.FreeCamera;
                if (this.keysAB) {
                    let camera = this.scene.activeCamera as BABYLON.FreeCamera;
                    let factor = 1 + this.keysAB * dSec / 2; // /2 to make it less fast
                    camera.position.y *= factor;
                }
                if (this.keysTS && this.viewer.osmScene) {
                    let actualScale = this.viewer.osmScene.webARroot.scaling.x;

                    let factor = 1 + this.keysTS * dSec / 1; //  /10 to make it less fast
                    let newScale = actualScale * factor; // "pointer" to scale of "everyting"
                    if (newScale > 1 / 1.) { newScale = 1 / 1.; factor = 1; }
                    if (newScale < 1 / 36) { newScale = 1 / 36; factor = 1; } // limit to H0 model train scale
                    this.viewer.osmScene.webARroot.scaling = new BABYLON.Vector3(newScale, newScale, newScale);
                    // if the universe get shrinked, my position should too:
                    camera.position.x *= factor;
                    camera.position.z *= factor;
                    // and the ground rises to a table:
                    this.viewer.osmScene.webARroot.position.y = 1 - actualScale // 1-1/36  1-0.03  0-0.97
                    //console.log(this.viewer.osmScene.webARroot.position.x,actualScale)
                }

            });

        }//allButtons

        return this.webXR;
    }


    /**
     * If the user sets the parameter, this is called and activates the WebXR/VR mode.
     * @param vz forward/backward speed by the controls
     * @param distFactor Factor to calculate maximal speed by the distance
     * @param dx Delta x direction (distance)
     * @returns modified forward/backward speed
     */
    collisionCheck(vz: number, distFactor: number, dx: number): number {

        let rayForward = Math.sign(vz);
        if (vz != 0) {
            if (rayForward != this.rayLastForward) {
                this.rayLastForward = rayForward;
                //console.log("rayForward: ",rayForward);
                this.rayHelper.attachToMesh(
                    this.camera as unknown as BABYLON.AbstractMesh,
                    new BABYLON.Vector3(0, 0, rayForward < 0 ? +1 : -1), // localMeshDirection
                    new BABYLON.Vector3(0, -0.1, 0), //localMeshOrigin
                    30 // length
                );
            }
        }

        let pickingInfo = this.scene.pickWithRay(this.ray); // , null, false,
        if (pickingInfo && pickingInfo.distance > 0 && vz != 0) {

            let dist = pickingInfo.distance - 0.4; // 0.4m min distance   pickResult
            let vzMax = dist * distFactor; // -m/s

            if (rayForward * vz > vzMax) {
                vz = rayForward * vzMax;
            }
            if (rayForward * vz > dist / dx) { // m/s
                vz = rayForward * dist / dx;
            }

            //console.log(dist, vzMax,dist/dSec,-this.velocity.z );
        }
        return vz;
    }

} //class ContolF4



/*
 * This Mouse controler class was coded after the BJS example.
 *
 * The BJS standard controls have arrays of key codes for funtions. Like [Cursor-Up and Key-W].
 * This does not use arrays bud write it in the code explicit.
 * Is it realy needed to check if the key is used in the control? Yes if preventDefault shall work.
 */
class CameraMouseControlO2W { /////////////////////////////////////// CameraMouseControlO2W (BABYLON CONTROL) //////////////////////////////

    /** HTML canvas, using this controler */
    private element: HTMLCanvasElement | null;
    /** BJS engine */
    private engine: BABYLON.Engine;
    /** Used camera */
    public camera = this.control.camera;

    /** Funtion, called if a mouse butten is pressed */
    private _onMouseDown: any; // ??? function(HTMLElement);
    /** Funtion, called if a mouse butten is moved */
    private _onMouseMove: any;
    /** Funtion, called if a mouse butten is released */
    private _onMouseUp: any;
    /** Funtion, called if a touch screen is pressed */
    private _onTouchDown: any;
    /** Funtion, called if a touch screen is swiped */
    private _onTouchMove: any;
    /** Funtion, called if a touch screen is unpressed */
    private _onTouchUp: any;
    /** Funtion, called if a mouse or touch click happend */
    private _onClick: any;

    /** mouse or touch state: 0=no, 1st, 2nd */
    private down: number = 0;
    /** mouse or touch pressed near canvas frame */
    private downNearFrame: boolean = false;
    /** Last screen coordiante X */
    private lastX: number = -1;
    /** Last screen coordiante Y */
    private lastY: number = -1;
    /** Last screen coordiante move delta */
    private lastD: number = -1;

    /** BJS scene */
    private scene: BABYLON.Scene;

    /** CameraMouseControlO2W contructor
     * @param control  using this mouse control
     */
    constructor(private control: ControlO2W) {
        this.control = control;
        this.scene = control.scene;
        this.scene.preventDefaultOnPointerDown = false; // Not a clear solution! Todo???
        this.engine = this.scene.getEngine();
        this.element = this.engine.getRenderingCanvas();
    }

    /** Rewuest the class name */
    getClassName(): string { return "CameraMouseControlO2W"; };

    /** Rewuest the type name */
    getTypeName(): string { return "MouseInputOSM2World"; };

    /** Rewuest the simple name */
    getSimpleName(): string { return "MouseO2W"; };


    /** Inactivate the control, detach all events */
    detachControl(): void {
        if (this._onMouseDown && this.element) {
            this.element.removeEventListener("mousedown", this._onMouseDown);
            this.element.removeEventListener("mousemove", this._onMouseMove);
            this.element.removeEventListener("mouseup", this._onMouseUp);
            this.element.removeEventListener("touchstart", this._onTouchDown);
            this.element.removeEventListener("touchmove", this._onTouchMove);
            this.element.removeEventListener("touchend", this._onTouchUp);
            this.element.removeEventListener("click", this._onClick);

            this._onMouseDown = null;
            this._onMouseMove = null;
            this._onMouseUp = null;
            this._onTouchDown = null;
            this._onTouchMove = null;
            this._onTouchUp = null;
            this._onClick = null;
        }
    };


    /** Activate the control, attach all events */
    attachControl(noPreventDefault?: boolean): void {

        //  let _this = this; //do???  is it the same as bind?
        if (!this._onMouseDown) {
            let _this = this; // bind

            this._onMouseDown = function(evt: MouseEvent) { //  HTMLElement
                _this.onPointDown(evt.clientX, evt.clientY, evt.button == 0 ? 1 : 2); // first/second button
                if (!noPreventDefault) evt.preventDefault();
            };

            this._onMouseMove = function(evt: MouseEvent) {
                _this.onPointMove(evt.clientX, evt.clientY);
                if (!noPreventDefault) evt.preventDefault();
            };

            this._onMouseUp = function(evt: MouseEvent) {
                _this.onPointUp();
                if (!noPreventDefault) evt.preventDefault();
            };


            this._onTouchDown = function(evt: TouchEvent) { //  HTMLElement


                if (evt.touches.length > 1)
                    _this.onPointDown(
                        evt.touches[0].pageX, evt.touches[0].pageY, 2,
                        evt.touches[1].pageX, evt.touches[1].pageY)
                else _this.onPointDown(evt.touches[0].pageX, evt.touches[0].pageY, 1); // single/double touch


                if (!noPreventDefault) evt.preventDefault();
            };

            this._onTouchMove = function(evt: TouchEvent) {
                switch (evt.touches.length) {
                    case 0:
                        _this._onTouchUp();
                        break;
                    case 1:
                        _this.onPointMove(evt.touches[0].pageX, evt.touches[0].pageY);
                        break;
                    case 2:
                        _this.onPointMove(
                            evt.touches[0].pageX, evt.touches[0].pageY,
                            evt.touches[1].pageX, evt.touches[1].pageY)
                        break;
                }
                if (!noPreventDefault) evt.preventDefault();
            };

            this._onTouchUp = function(evt: TouchEvent) {
                console.log("_onTouchUp")
                _this.onPointUp();
                if (!noPreventDefault) evt.preventDefault();
            };


            this._onClick = function(evt: MouseEvent) {
                //console.log("_onClick", evt)
                _this.onClick_PointOnScreen(evt); // CameraMouseControlO2W
                if (!noPreventDefault) evt.preventDefault();
            };

            //            let element = this.engine.getInputElement();
            if (this.element) {
                this.element.addEventListener("mousedown", this._onMouseDown, false);
                this.element.addEventListener("mousemove", this._onMouseMove, false);
                this.element.addEventListener("mouseup", this._onMouseUp, false);
                this.element.addEventListener("touchstart", this._onTouchDown, false);
                this.element.addEventListener("touchmove", this._onTouchMove, false);
                this.element.addEventListener("touchend", this._onTouchUp, false);
                this.element.addEventListener("focusout", this._onTouchUp);
            }
            document.addEventListener('click', this._onClick); //When click event is raised
            //          document.addEventListener('click', this.onClick_PointOnScreen.bind(this)); //When click event is raised
        }

    };


    /**
     * Called if the user clicks on the screen on an OSM object
     * The pointer position on the screen is used to get a list of faces.
     * The mash of the nearest face and the index of the face
     * is used to get the OSM id.
     * A default or user reaction is called
     * @param event  on click event structure
     */
    onClick_PointOnScreen(event: MouseEvent): void { // evt:any

        if (!event.shiftKey) return;

        console.log(this.scene.pointerX, this.scene.pointerY);
        // We try to pick an object
        let pickResult = this.scene.pick(this.scene.pointerX, this.scene.pointerY);
        if (!pickResult) return;

        let mesh = pickResult.pickedMesh;
        let faceId = pickResult.faceId;

        // pickResult.subMeshId seems not usefull in this case
        console.log("pickedMesh", mesh);
        console.log("faceId", faceId);

        if (!mesh || !mesh.startsIndex) return // return console.log("NO mesh.startsIndex")

        for (let i = mesh.startsIndex.length - 1; i >= 0; i--) {
            if (i < 0 || mesh.startsIndex[i] <= faceId) {
                //  let osmId = mesh.startsOsmId[i]; if (osmId == "") return;
                if (!mesh.osmIds) return console.log("NO mesh.osmIds (not with animations!)")
                let objIn = mesh.startsOidIx[i];
                let osmId = mesh.osmIds[objIn]
                let type = osmId.substr(0, 1);
                let nr = osmId.substr(1);
                console.log("Click on OSM object #" + objIn + "=" + osmId + ". submesh #" + i + "  face #" + faceId);
                if (nr != "0")
                    this.control.viewer.parameter.selected(type, nr);

                break;
            }//found
        }//startsIndex

    }



    /** As a mouse butten is pressed or a screen is touched,
     * the position is stored.
     * @oaram px actual screen position x
     * @oaram py actual screen position y
     * @oaram down first/2nd mouse touch
     * @oaram px2 second screen position x
     * @oaram px2 second screen position y
     */
    onPointDown(px: number, py: number, down: number, px2?: number, py2?: number): void {
        this.down = down;
        this.lastX = px;
        this.lastY = py;

        if (px2 && py2) { // zoom like with mouse weehl?
            this.lastD = phytagoras(px - px2, py - py2);
        }

        // Don't rotate/slide if the pointing started near the window frame
        let x = px / window.innerWidth - 0.5 // scale to +/-0.5
        let y = py / window.innerHeight - 0.5
        this.downNearFrame = ((Math.abs(x) > 0.4) || (Math.abs(y) > 0.4));

        var show = "default";
        if (down == 1) show = "move"; // grabbing,move,all-scroll
        if (down == 2) show = "crosshair"; // crosshair pointer
        document.body.style.cursor = show;
    }

    /** As a mouse butten or a screen is moved,
     * the position delta is calculated and the reaction is done.
     * @oaram px actual screen position x
     * @oaram py actual screen position y
     * @oaram px2 second screen position x
     * @oaram px2 second screen position y
     */
    onPointMove(px: number, py: number, px2?: number, py2?: number): void {
        // Not dragging or not enabled.
        if (this.down == 0) return //  todo: Handle 2 buttons.

        let dx = this.lastX - px;
        let dy = this.lastY - py;
        this.lastX = px;
        this.lastY = py;

        if (this.down == 1) { // slide
            let betaLimit = rad(90 - 4);
            let beta = this.camera.beta; if (beta > betaLimit) beta = betaLimit; // to avoid divisioh by zero
            let distFactor = 1 / Math.cos(beta); // view down rad(0): 1/1 => 1 -- view flat rad(90): 1/0 => infinite
            let angleFactor = Math.sin(beta); //    view down rad(0): equal dy -- view flat rad(90): fast far, slow near.
            let signedFactor = (0.5 - py / window.innerHeight) * 2 // top..down -0..-1 + 0.5 => +/-0.5 => +/-1
            let heightFaktor = 1 + (signedFactor * angleFactor); // top = +0.5 = much effect + 1 = much factor
            let panningFaktor = this.control.mode == "walk" ? 10 : 1;
            let fx = dx * heightFaktor * panningFaktor;
            let fz = dy * heightFaktor * panningFaktor * distFactor;

            let radiusFaktor = (2 + this.camera.radius) / 1800;  // why 1800?  // factor 1 + radius is logic. But why 2+ ???

            // äää

            fz = this.control.collisionCheck(fz, 100 * panningFaktor, radiusFaktor);

            /**
            let pickingInfo = this.control.scene.pickWithRay(this.control.ray); // , null, false,
            if(pickingInfo && pickingInfo.distance > 0){

            //let pickResult = this.control.scene.pick(window.innerWidth /2, window.innerHeight/2);  // center of screen
            //if (pickResult) {

                let dist = pickingInfo.distance-0.4; // 0.4m min distance
                let vzMax = dist*100*panningFaktor; // -m/s
                if( -fz >  vzMax) {
                     fz = -vzMax;
                }
                if( -fz >  dist/radiusFaktor) { // ??? m/s
                     fz = -dist/radiusFaktor;
                }
                console.log(dist,fz);
            }
            **/

            //console.log(heightFaktor, signedFactor, angleFactor, this.camera.radius)
            this.camera.target.x += (-Math.sin(this.camera.alpha) * fx + Math.cos(this.camera.alpha) * fz) * radiusFaktor;
            this.camera.target.z += (+Math.sin(this.camera.alpha) * fz + Math.cos(this.camera.alpha) * fx) * radiusFaktor;
        } else { // rotate
            let dx1 = dx / window.innerWidth;
            let dy1 = dy / window.innerHeight;
            this.camera.alpha += dx1 * 10; // fast rotating
            this.camera.beta += dy1 * 10;

            if (px2 && py2) { // zoom like with mouse weehl?
                let d = phytagoras(px - px2, py - py2);
                let delta = this.lastD - d;
                this.camera.radius += (delta * this.camera.radius / 200);
                this.lastD = d;
            }
        }

    }

    /** As a mouse butten or a screen is relased,
     * the position is noted and reactions are done.
     */
    onPointUp(): void { //px: number, py: number, down: number
        this.down = 0;
        document.body.style.cursor = "default";

        //if(!point.moved && point.down==2) { // && !point.time) // no Drag, Kick!
        //	map.PointOnScreen(event);
        //var popup = document.body //getElementById(/*"myPopup"* /);
        //popup.classList.toggle("show");

    }

    /**
     * Cyclically check the state of the mouse/touch inputs and reactions are done
     */
    checkInputs(): void {

        if (this.down == 0) return;

        let dSec = this.engine.getDeltaTime() / 1000;
        let x = this.lastX / window.innerWidth - 0.5 // scale to +/-0.5
        let y = this.lastY / window.innerHeight - 0.5

        if (this.down == 1) { // slide
            //console.log(this.lastX,window.innerWidth)
            //console.log(x,x* dSec * this.camera.radius / 1800)

            if (this.downNearFrame) return;

            if (Math.abs(x) > 0.4) {
                this.camera.target.x -= -Math.sin(this.camera.alpha) * dSec * this.camera.radius / 1 * Math.sign(x);
                this.camera.target.z -= +Math.cos(this.camera.alpha) * dSec * this.camera.radius / 1 * Math.sign(x);
            }
            if (Math.abs(y) > 0.4) {
                this.camera.target.x -= +Math.cos(this.camera.alpha) * dSec * this.camera.radius / 1 * Math.sign(y);
                this.camera.target.z -= +Math.sin(this.camera.alpha) * dSec * this.camera.radius / 1 * Math.sign(y);
            }
        }
        else { // rotate
            if (Math.abs(x) > 0.4)
                this.camera.alpha -= (dSec * Math.sign(x) * 1);
        }

    }

}




/**
 * Keyboard controler
 */
class CameraKeyboardControlO2W { /////////////////////////////////////// CameraKeyboardControlO2W (BABYLON CONTROL) //////////////////////////////

    /** HTML canvas, using this controler */
    private element: HTMLCanvasElement | null;
    /** BJS engine */
    private engine: BABYLON.Engine;
    /** Used camera */
    public camera = this.control.camera;

    /** Array of all actual pressed keys */
    private keysDown: any = {};
    /** Count of all actual pressed keys */
    private keysDownCount: number = 0;

    /** Funtion, called if a key is pressed */
    private _onKeyDown: any; // ??? function(HTMLElement);
    /** Funtion, called if a key is released */
    private _onKeyUp: any;
    /** Funtion, called if the user device gets outside the canvas */
    private _onLostFocus: any;

    //ivate fly:boolean	= false;
    //ivate lastHigh: boolean = false;
    /** Maximal move speed */
    private maxSpeed: number = 70; // 30 m/s
    /** Move start ramp: unlimited in this case */
    private accePosition: number = 1000000; // 100   acc. m/s
    /** Rotate start ramp: unlimited in this case */
    private acceRotation: number = 1000000; // 30 acc. degr/s  -- no delay/ramp
    /** Maximal rotation speed in degr/s -- 8s for 1 rotation  */
    private maxRotation: number = rad(360 / 8);

    /** Actual speed / mass inertia relaitv ot object / LOCAL */
    private velocity = new BABYLON.Vector3();
    /** Actual rotation */
    private spinning = new BABYLON.Vector3(); // also yerk (ruck) ?

    /** CameraKeyboardControlO2W constructor
     * @param scene BJS scene
     * @param control control, using this key control
     */
    constructor(scene: BABYLON.Scene, private control: ControlO2W) {
        this.control = control;
        this.engine = scene.getEngine();
        this.element = this.engine.getRenderingCanvas();
        this.setKeyCodes();
        this.control.keysDown = this.keysDown;
        //this.camera is set by BABYLON calling attachControl. It may also be the webVRCamera!

    }


    /** Set the codes of all expeted keys */
    setKeyCodes(): void {
        const keyCodes: string[] = [
            'KeyA', 'ArrowLeft', // cursor keye
            'KeyD', 'ArrowRight',
            'KeyW', 'ArrowUp',
            'KeyS', 'ArrowDown',

            'KeyQ', 'KeyE', // rotate
            'KeyR', 'KeyF', // nick
            'KeyG', 'KeyT', // elevate

            'KeyY', 'KeyH', // zoom (Y=Z at German keyboard) Mind the Compas! ???

            'PageUp', 'PageDown',
            'Backslash', 'BracketRight', // Left of "Enter"; UK or US keyboard: ] and \ German keypbard: + and #

            'OSLeft', 'OSRight',
            'metaKey',  // Chrome OSkey
            'shiftKey', // 'ShiftLeft', 'ShiftRight',
        ]
        keyCodes.forEach((code: string) => {
            this.keysDown[code] = false;
        });
    }


    /** Rewuest the class name */
    getClassName(): string { return "CameraKeyboardControlO2W"; };
    /** Rewuest the type name */
    getTypeName(): string { return "KeyboardInputOSM2World"; };
    /** Rewuest the simple name */
    getSimpleName(): string { return "KeysO2W"; };


    /** Inactivate the control, detach all events */
    detachControl(): void { // CameraKeyboardControlO2W
        if (this._onKeyDown && this.element) {
            this.element.removeEventListener("keydown", this._onKeyDown);
            this.element.removeEventListener("keyup", this._onKeyUp);
            BABYLON.Tools.UnregisterTopRootEvents(window, [{
                name: "blur", //??? does not work!
                handler: this._onLostFocus
            }]);
            this.keysDown = [];
            this._onKeyDown = null;
            this._onKeyUp = null;
            this._onLostFocus = null;
        }
    };


    /** Activate the control, attach all events */
    attachControl(noPreventDefault?: boolean): void { // CameraKeyboardControlO2W

        let _this = this; //do???  is it the same as bind?
        if (!this._onKeyDown) {
            //    element.tabIndex = 1; // what's this?

            // KEY DOWN
            this._onKeyDown = function(evt: KeyboardEvent) { //  HTMLElement
                if (_this.keysDown[evt.code] != undefined && _this.keysDown[evt.code] == false) { // key is used by this control?
                    _this.keysDown[evt.code] = true;
                    _this.keysDown.shiftKey = evt.shiftKey
                    _this.keysDown.metaKey = evt.metaKey
                    _this.keysDownCount++;
                    console.log("  down", evt.code, _this.keysDownCount)
                    if (!noPreventDefault) {
                        //console.log("noPreventDefault", noPreventDefault);
                        evt.preventDefault();
                    };
                };
            };

            // KEY UP
            this._onKeyUp = function(evt: KeyboardEvent) {
                if (_this.keysDown[evt.code] != undefined) {
                    _this.keysDown[evt.code] = false;
                    _this.keysDown.shiftKey = evt.shiftKey
                    _this.keysDownCount--;
                    console.log("    up", evt.code, _this.keysDownCount)
                    if (!noPreventDefault) {
                        evt.preventDefault();
                    };
                };
            };


            this._onLostFocus = function() { // evt: HTMLElement
                //console.log("key lost: false all keys!!!", evt)
                _this.setKeyCodes();
            };

            //let engine = this.camera.getEngine();
            //let element = engine.getInputElement();
            if (this.element) {
                this.element.addEventListener("keydown", this._onKeyDown, false);
                this.element.addEventListener("keyup", this._onKeyUp, false);
            }
            BABYLON.Tools.RegisterTopRootEvents(window, [{
                name: "blur", //???
                handler: this._onLostFocus
            }]);
        }
    };



    /**
     * Cyclically check the state of the key inputs and reactions are done
     */
    checkInputs(): void { // CameraKeyboardControlO2W

        let camera = this.control.camera;

        // We use the original wheel control but munipulate it this way (in the key control!)
        // wheelDeltaPercentage does NOT work well :( todo:BJS im forum meckern
        // not good either:  camera.wheelPrecision = 100 / camera.radius;

        // This is keys only. See also onPointMove

        // There are pards, needed cyclically!   if (!this.keysDownCount) return; // ------------------>>>

        let dSec = this.engine.getDeltaTime() / 1000;

        let rotation = new BABYLON.Vector3(camera.beta, camera.alpha, 0);
        let position = camera.target.clone();
        //position.y = .position.y;

        let aPosition = new BABYLON.Vector3() // acceleration of porition and rotation, caused by user action
        let aRotation = new BABYLON.Vector3()
        let aRadius = new BABYLON.Vector2();

        this.keys_F4plus(aPosition, aRotation, aRadius);

        let factHeight = camera.position.y / 10;
        if (factHeight < this.control.parameter.minHeight)
            factHeight = this.control.parameter.minHeight

        // Accelerate velocity: velocity += acceleration * (acceleratoin * dSec time)
        this.velocity.addInPlace(aPosition.scale(this.accePosition * dSec * factHeight))
        let minV = BABYLON.Vector3.One().scale(-this.maxSpeed * factHeight);
        let maxV = BABYLON.Vector3.One().scale(+this.maxSpeed * factHeight);
        this.velocity = BABYLON.Vector3.Clamp(this.velocity, minV, maxV);
        this.velocity.x /= 2;  // slow side shift
        this.velocity.y /= 8;  // slow elevation

        this.velocity._z = this.control.collisionCheck(this.velocity._z, 10, dSec);

        /**
        let rayForward = Math.sign(this.velocity._z);
        if(this.velocity._z != 0){
            if(rayForward != this.control.rayLastForward) {
                this.control.rayLastForward = rayForward;
                console.log("rayForward: ",rayForward);
                this.control.rayHelper.attachToMesh(
                    this.camera as unknown as BABYLON.AbstractMesh,
                    new BABYLON.Vector3(0, 0, rayForward < 0 ? +1 : -1), // localMeshDirection
                    new BABYLON.Vector3(0, -0.1, 0), //localMeshOrigin
                    30 // length
                );
            }
        }

        let pickingInfo = this.control.scene.pickWithRay(this.control.ray); // , null, false,
        if(pickingInfo && pickingInfo.distance > 0 && this.velocity._z != 0){

            let dist = pickingInfo.distance-0.4; // 0.4m min distance   pickResult
            let vzMax = dist*10; // -m/s

            if( rayForward * this.velocity.z >  vzMax) {
                this.velocity.z = rayForward * vzMax;
            }
            if( rayForward * this.velocity.z >  dist/dSec) { // m/s
                 this.velocity.z = rayForward * dist/dSec;
            }

            //console.log(dist, vzMax,dist/dSec,-this.velocity.z );
        }
        **/

        this.spinning.addInPlace(aRotation.scale(this.acceRotation * dSec))
        minV = BABYLON.Vector3.One().scale(-this.maxRotation);
        maxV = BABYLON.Vector3.One().scale(+this.maxRotation);
        this.spinning = BABYLON.Vector3.Clamp(this.spinning, minV, maxV);
        //  this.spinning.x *= Math.cos(rotation.x) + 0.1 // beta   what for ???

        let moving = new BABYLON.Vector3();
        // Quaternion works odd ???  this.velocity.scale(dSec).rotateByQuaternionToRef(rotation.toQuaternion(), moving);
        moving.x = - Math.sin(rotation.y) * this.velocity.x + Math.cos(rotation.y) * this.velocity.z
        moving.z = + Math.sin(rotation.y) * this.velocity.z + Math.cos(rotation.y) * this.velocity.x
        moving.y = this.velocity.y;

        // Increment position and rotation
        position.addInPlace(moving.scale(dSec));
        rotation.addInPlace(this.spinning.scale(dSec));
        if (this.control.mode != "walk"
            && this.control.viewer.parameter.test < 2 // ??? case mode: checkInputs_default
        ) {
            let h = camera.radius;
            let high = h > this.control.viewer.envRadius / 2; // 6000
            if (high) {
                rotation.x -= dSec;
                if (rotation.x < 0) // if down-headover
                    rotation.x = 0; // to down
            } else { // low
                let dif = rad(25) - rotation.x;
                if (dif > 0) {
                    if (dif > dSec)
                        dif = dSec;
                    rotation.x += dif;
                }
                if (rotation.x > rad(80)) // almost horizontal
                    rotation.x = rad(80); // slightly down
            }
        }

        // If FPS too low, reset velocity and spin
        if (dSec > 0.9902) {	// MAX_DELTA
            this.velocity.set(0, 0, 0);
            this.spinning.set(0, 0, 0);
            aPosition.set(0, 0, 0);
            aRotation.set(0, 0, 0);
        }

        position.y = limit(this.control.parameter.minHeight, position.y, this.control.parameter.maxHeight);

        //??? rotation.z = limit(-rad(90), rotation.z, +rad(90));
        //??? rotation.x = limit(-rad(0), rotation.x, +rad(180)); // todo 45 ???
        // 180 = up, 0 = down, 90 = view horizontal: not up (not 3rd person under ground) (API different!: 0=horizontal -90=down)
        rotation.y = rotation.y % (rad(360));


        /*
         *  In oposition to the F4 Map, OSM2World uses the right/left A/D Keys
         *  to rotate the camera in first person mode.
         *  An BABYLON.ArcRotateCamera can't do this itselve
         *  The target has to be moved in a cirle around the camera
         */

        if (
            this.control.mode != "f4" &&
            (
                this.control.keysDown.KeyA ||
                this.control.keysDown.KeyD
            )
        ) {
            // calc floor distance target-camera by angle. Must be the same as by position and positions. Both must be the same
            let y = camera.position.y - camera.target.y
            let distAH = Math.sqrt(Math.abs(camera.radius * camera.radius - y * y))

            // calc new target position from the new rotation.y
            let xNew = camera.position.x - Math.cos(rotation.y) * distAH;
            let zNew = camera.position.z - Math.sin(rotation.y) * distAH;

            // calc delta actual-new and correkt the new position
            position.x -= (camera.target.x - xNew);
            position.z -= (camera.target.z - zNew);
        }

        camera.target.set(position.x, position.y, position.z);
        camera.alpha = rotation.y;
        camera.beta = rotation.x;
        camera.radius += (aRadius.x * dSec * this.camera.radius / 1);// zoom like with mouse weehl?
        // camera.rebuildAnglesAndRadius(); // NOT good

        // there is no ramp down yet. so the speed is set to 0 at once
        this.velocity.set(0, 0, 0);
        this.spinning.set(0, 0, 0);

        /// Not used with F4???

        // the more the camera is high abower ground, the more fast the camera moves
        let s = 300 / camera.position.y;  // in meter per mouse move // There is no PanningDeltaPercentage :( todo:BJS im forum meckern
        // if the camera is very close to the ground it would stop moving. avoid this
        if (s > 30)
            s = 30;
        camera.panningSensibility = s;

        camera.pinchPrecision = 50 / camera.position.y;

        // "KeyY/Z":  // Zoom (Z on a german keyboard)
        let k = this.keysDown;

        if (k.KeyY) { // zoom in
            let viewAngle = camera.fov / 1.03
            if (viewAngle < rad(.01)) viewAngle = rad(.01)
            camera.fov = viewAngle
        }

        if (k.KeyH) { // zoom out
            let viewAngle = camera.fov * 1.03
            if (viewAngle > rad(120)) viewAngle = rad(120)
            camera.fov = viewAngle
        }


        // WebXR ///////////////////////
        //if(this.control.webXR) {
        //    if(this.control.keysAB)
        //    alert(": "+this.control.keysAB)
        //    let camera = this.control.scene.activeCamera as BABYLON.FreeCamera;
        //    let factor = 1 + this.control.keysAB * dSec;
        //    camera.position.y *= factor;
        //}


    }; //checkInputs -  CameraKeyboardControlO2W



    ///////////////////////////////////////////////////////////////////////////////////

    /**
     * Cyclically check the state of the key inputs in F4_mode
     * @param aPosition Acceleration input of the position
     * @param aRotation Acceleration input of the rotation
     * @param aRadius   Acceleration input of the distance to view target
     */
    keys_F4plus(aPosition: BABYLON.Vector3, aRotation: BABYLON.Vector3, aRadius: BABYLON.Vector2): void {

        // "like F4" but extendet with QE for tile right/ArrowLeft
        //   RF for view up/down and TG elevate up/down.  Shift NOT used yet

        let k = this.keysDown;

        if (k.KeyR && (k.OSLeft || k.OSRight || k.metaKey)) { // command-R => Reload page
            this.setKeyCodes();
            window.location.reload(/*k.OSRight*/); // if right key is used: load new from broswer
            return;
        }

        // Accelerate
        let aX = this.activity(k.KeyQ, k.KeyE);
        let aZ = this.activity(k.ArrowUp || k.KeyW, k.ArrowDown || k.KeyS); // forward
        let aY = this.activity(k.PageUp || k.BracketRight, k.PageDown || k.Backslash);

        // Spin & Shift
        let sX = this.activity(k.KeyR, k.KeyF);
        let sY = this.activity(k.ArrowLeft || k.KeyA, k.ArrowRight || k.KeyD); // arc horizontal
        if (k.shiftKey) { sX /= 400000; sY /= 400000; } // if shift is pressed, slow rotation

        // Additiv setting of 3DObject control
        aPosition.addInPlace(new BABYLON.Vector3(+aX, -aY, +aZ));
        aRotation.addInPlace(new BABYLON.Vector3(-sX, -sY, 0));

        // Zoom
        let aR = this.activity(k.KeyT, k.KeyG);
        aRadius.x += aR;

        //        aPosition.addInPlace(new BABYLON.Vector3(+aX, -aY / 30, +aZ));
        //        aRotation.addInPlace(new BABYLON.Vector3(-sX / 10, -sY, 0));

    }
    //keys_F4plus



    /**
     * return an normed +/-1 value to de-/increse
     * @param sub  boolean  decrease
     * @param add  boolean  increase
     * @return     number   delta normed to 1
     */
    activity(sub: boolean, add: boolean): number {
        let a = 0;
        if (sub) a -= 1;
        if (add) a += 1; // If both: 0
        return a;
    }


}
//class CameraKeyboardControlO2W
