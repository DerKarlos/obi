use three_d::*;

pub struct Control {
    pub camera: Camera,
    control: three_d::FlyControl,
}

// impl ::std::marker::Copy for Control { }

impl Control {
    pub fn new(window: &Window, context: &Context) -> Control {
        // Create a camera
        let o = 200.; //       waste        bus stop   Grieche
        let x = -1491.816; // -963.2990; // -281.686  -1491.816   !!! x/z not = 0.0 !!!
        let z = -721.1010; // -1295.737; // -742.332  -721.1010

        // -281686.0, 0.0, 742332.0
        let camera = Camera::new_perspective(
            &context,
            window.viewport().unwrap(),
            vec3(x + o, 0.0 + o, z), // position -- 0.1 because of up ???
            vec3(x, 0.0, z),         // target   -- 0.1 because of up ?
            vec3(0.0, 1.0, 0.0),     //                            up ?
            degrees(45.0),           // field_of_view_y Radians
            0.1,                     // min / max distance
            10000.0,
        )
        .unwrap();

        let control = FlyControl::new(0.1);
        //  OrbitControl::new(*camera.target(), 1.0, 5000.0); // Fly, FirstPerson, Orbit

        // return this new instance:
        Control { camera, control }
    } //new

    pub fn render_loop_exit(&mut self, frame_input: &mut FrameInput) -> bool {
        let mut exit = false;

        self.control
            .handle_events(&mut self.camera, &mut frame_input.events)
            .unwrap();

        for event in frame_input.events.iter() {
            match event {
                /*
                                Event::MouseMotion { delta, button, .. } => {

                                    if *button == Some(MouseButton::Left) {
                                        self.camera.rotate_around_with_fixed_up(
                                            &self.camera.target().clone(), // clone beause what ??? Is that normal?
                                            0.3 * delta.0 as f32, // 0.1
                                            0.3 * delta.1 as f32, // 0.1
                                        ).unwrap();
                                    }

                                    if *button == Some(MouseButton::Right) {
                                        let mut dist = self.camera.position().y;
                                        if dist<1.1 { dist=1.0; }

                                        // ??? this.camera.target.x += (-Math.sin(this.camera.alpha) * fx + Math.cos(this.camera.alpha) * fy) * (2 + this.camera.radius) / 1800; // factor 1 + radius is logic. But why 2+ ???
                                        // ??? this.camera.target.z += (+Math.sin(this.camera.alpha) * fy + Math.cos(this.camera.alpha) * fx) * (2 + this.camera.radius) / 1800; // why 1800?

                                        self.camera.translate( &Vec3::new(
                                            // ! relativ to view angle ! not on ground !  Set target.y = 0?
                                            // Translate the camera by the given change while keeping the same view and up directions.
                                            0.05 * dist * delta.1 as f32, 0.0,
                                            0.05 * dist * delta.0 as f32,
                                        ) ).unwrap();
                                    }

                                }//MouseMotion

                                Event::MouseWheel { delta, .. } => {

                                    /**/
                                    // What??? todo: same code local works fine, tree-d code only zooms out!!!
                                    let point     =   self.camera.target().clone();
                                    let position  =  *self.camera.position();
                                    let distance  =  point.distance(position);
                                    let direction = (point - position).normalize();
                                    let target    = *self.camera.target();
                                    let up        = *self.camera.up();
                                    let new_distance = distance - (0.02 * delta.1 as f32);
                                    let new_position = point - direction * new_distance;
                                    let _dump = self.camera.set_view(new_position, new_position + (target - position), up);
                                    // println!("x {} {}",delta.1, distance);
                                    /**/

                                    /*
                                    self.camera
                                        .zoom_towards(&self.camera.target().clone(), 0.1 * delta.1 as f32, 5.0, 1000.0)
                                        .unwrap();
                                    println!("delta.1 {}",delta.1);
                                    */
                                }
                */
                Event::KeyPress { .. } => {
                    // State, Key,
                    exit = true;
                }

                _ => {} // default
            }
        }

        // Ensure the viewport matches the current window viewport which changes if the window is resized
        self.camera.set_viewport(frame_input.viewport).unwrap();

        exit
    } //render_loop_exit
} //Control
